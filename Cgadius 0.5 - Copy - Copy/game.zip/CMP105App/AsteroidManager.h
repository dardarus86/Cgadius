#pragma once
#include "Asteroid.h"
#include <math.h>
#include <iostream>
#include "Framework/Collision.h"
#include "Framework/GameObject.h"
#include <vector>

class AsteroidManager
{
public:
	AsteroidManager();
	~AsteroidManager();

	void spawn();
	void update(float dt);
	void deathCheck();
	void render(sf::RenderWindow* window);

	



private:
	std::vector<Asteroid> asteroids;
	sf::Texture texture;
	
};

