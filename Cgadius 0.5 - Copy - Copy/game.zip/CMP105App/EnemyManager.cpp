#include "EnemyManager.h"

EnemyManager::EnemyManager()
{

	Enemygreytexture.loadFromFile("gfx/enemyship1.png");
	Enemygreentexture.loadFromFile("gfx/enemyship2.png");
	Enemypurpletexture.loadFromFile("gfx/enemyship3.png");

	for (int i = 0; i < 20; i++)
	{
		Enemygrey.push_back(Enemy());
		Enemygrey[i].setAlive(false);
		Enemygrey[i].setTexture(&Enemygreytexture);
		Enemygrey[i].setSize(sf::Vector2f(60, 50));

	}

	for (int i = 0; i < 10; i++)
	{
		Enemygreen.push_back(Enemy());
		Enemygreen[i].setAlive(false);
		Enemygreen[i].setTexture(&Enemygreentexture);
		Enemygreen[i].setSize(sf::Vector2f(60, 50));

	}

	for (int i = 0; i < 10; i++)
	{
		Enemypurple.push_back(Enemy());
		Enemypurple[i].setAlive(false);
		Enemypurple[i].setTexture(&Enemypurpletexture);
		Enemypurple[i].setSize(sf::Vector2f(60, 50));

	}
}

EnemyManager::~EnemyManager()
{}



void EnemyManager::update(float dt)
{

	//call update on all ALIVE asteroids
	for (int i = 0; i < Enemygrey.size(); i++)
	{
		Enemygrey[i].update(dt);
	}
	deathCheck();
}

//spawn new ball
//find a dead ball, make alive, move to spawn point, give random velocity
void EnemyManager::spawn()
{
	//wave 1 top
	Enemygrey[0].setPosition(260, 300);
	Enemygrey[1].setPosition(310, 240);
	Enemygrey[2].setPosition(380, 215);
	Enemygrey[3].setPosition(450, 210);
	//wave 1 bottom
	Enemygrey[5].setPosition(260, 420);
	Enemygrey[6].setPosition(310, 480);
	Enemygrey[7].setPosition(380, 520);
	Enemygrey[8].setPosition(450, 520);
	//wave 2 top
	Enemygrey[10].setPosition(840, 250);
	Enemygrey[11].setPosition(910, 180);
	Enemygrey[12].setPosition(910, 240);
	Enemygrey[13].setPosition(910, 300);
	//wave 2 bottom
	Enemygrey[14].setPosition(980, 480);
	Enemygrey[15].setPosition(1050, 410);
	Enemygrey[16].setPosition(1050, 470);
	Enemygrey[17].setPosition(1050, 530);

	for (int i = 0; i < Enemygrey.size(); i++)
	{


		if (!Enemygrey[i].isAlive())
		{
			Enemygrey[i].setAlive(true);
			Enemygrey[i].setVelocity(0, 50);
			Enemygrey[i].setPosition(260, 300);
			return;
		}
	}

}


void EnemyManager::deathCheck()
{

}


//Render all alive asteroids
void EnemyManager::render(sf::RenderWindow* window)
{
	for (int i = 0; i < Enemygrey.size(); i++)
	{
		if (Enemygrey[i].isAlive())
		{
			window->draw(Enemygrey[i]);
		}
	}
}

