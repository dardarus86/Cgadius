#pragma once
#include "Enemy.h"
#include <math.h>
#include <iostream>
#include "Framework/Collision.h"
#include "Framework/GameObject.h"
#include <vector>

class EnemyManager
{
public:
	EnemyManager();
	~EnemyManager();

	void spawn();
	void update(float dt);
	void deathCheck();
	void render(sf::RenderWindow* window);

private:
	std::vector<Enemy> Enemygrey;
	std::vector<Enemy> Enemygreen;
	std::vector<Enemy> Enemypurple;
	sf::Texture Enemygreytexture;
	sf::Texture Enemygreentexture;
	sf::Texture Enemypurpletexture;


};

