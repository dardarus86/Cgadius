#include "Square.h"

Square::Square()
{
	}

Square::~Square()
{
}

void Square::update(float dt)
{
	move(velocity*dt);
	// Check for collision with Left of window
	if (getPosition().x <= 0)
	{
		velocity.x = -velocity.x;
	}

	if (getPosition().x >= 1150)
	{
		velocity.x = -velocity.x;
	}

}