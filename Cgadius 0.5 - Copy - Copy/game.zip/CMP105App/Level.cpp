#include "Level.h"

Level::Level(sf::RenderWindow* hwnd, Input* in)
{
	window = hwnd;
	input = in;

	player.setInput(input);
	view1.reset(sf::FloatRect(0.f,0.f, 1200.f, 800.f));
	boss.loadFromFile("sfx/boss.ogg");
	sound.setBuffer(boss);
	sound.setVolume(35);
	
	// initialise game objects
	backgroundtexture.loadFromFile("gfx/background.png");
	playertexture.loadFromFile("gfx/playersprite.png");
		
	background.setTexture(&backgroundtexture);
	background.setSize(sf::Vector2f(6000, 800));
	background.setPosition(0, 0);
	
	player.setTexture(&playertexture);
	player.setSize(sf::Vector2f(75, 75));
	player.setPosition(50, 350);	

	wallManager.spawn();

	

	for (int i = 0; i < 20; i++)
	{
		enemyManager.spawn();
	}

	for (int i = 0; i < 10; i++)
	{
		asteroidManager.spawn();
	}
}

Level::~Level()
{
}

// handle user input
void Level::handleInput(float dt)
{
	player.handleInput(dt);

	
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::M))
	{
		sound.play();
	}
	 if (sf::Keyboard::isKeyPressed(sf::Keyboard::N))
	{
		sound.stop();
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
	{
		view1.move(dt+0.05f, 0);
	}

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
	{
		view1.move(dt - 0.005f, 0);
	}

	if (input->isKeyDown(sf::Keyboard::Right) && input->isKeyDown(sf::Keyboard::Space))
	{
		view1.move(dt +0.5f, 0);
	}

	 if (input->isKeyDown(sf::Keyboard::Left) && input->isKeyDown(sf::Keyboard::Space))
	{
		view1.move(dt -0.5f, 0);
	}
}

// Update game objects
void Level::update(float dt)
{
	enemyManager.update(dt);
	asteroidManager.update(dt);
	player.update(dt);
	

	view1.move(0.002f, 0);

	
	/*
	if (player.getPosition().x + player.getSize().x >= 5000)
	{
		view1.move(0.f, 0.f);
	}
	else if (player.getPosition().x + player.getSize().x >= 5000))
	{
		view1.move(0.002f, 0);
	}
	*/
	
}

// Render level
void Level::render()
{
	beginDraw();
	window->setView(view1);
	window->draw(background);
	wallManager.render(window);
	asteroidManager.render(window);
	enemyManager.render(window);
	window->draw(*player.getBullet());
	window->draw(player);
	endDraw();
	
}

// Begins rendering to the back buffer. Background colour set to light blue.
void Level::beginDraw()
{
	window->clear(sf::Color(100, 149, 237));
}

// Ends rendering to the back buffer, and swaps buffer to the screen.
void Level::endDraw()
{
	window->display();
}