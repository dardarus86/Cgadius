#pragma once
#include "Framework/GameObject.h"
#include "Framework/Collision.h"
class Wall : public GameObject
{
public:
	Wall();
	~Wall();

	

};
