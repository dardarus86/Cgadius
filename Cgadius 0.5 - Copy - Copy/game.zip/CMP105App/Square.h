#include "Framework/GameObject.h"
#include "Framework/Input.h"

class Square : public GameObject
{
public:
	Square();
	~Square();

	void update(float dt);


private:


};

