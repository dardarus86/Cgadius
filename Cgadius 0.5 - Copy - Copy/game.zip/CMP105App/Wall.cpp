#include "Wall.h"

Wall::Wall()
{
}

Wall::~Wall()
{}

